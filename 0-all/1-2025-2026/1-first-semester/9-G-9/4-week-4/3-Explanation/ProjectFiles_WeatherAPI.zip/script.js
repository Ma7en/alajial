function getWeatherData() {

    var city_name = document.getElementById('city_name').value;

    axios.get(`https://api.weatherapi.com/v1/forecast.json?key= 6a7f101d074d403ba3792519210110&q=${city_name}&days=3&aqi=no`)
    .then((response) => {
        console.log(response.data);
        let currentWeather = response.data.current;
        let location = response.data.location;


        let day1 = response.data.forecast.forecastday[1];
        let day2 = response.data.forecast.forecastday[2];

    //    Current Weather
        document.getElementById('location').innerText = location.name+', '+location.region;
        document.getElementById('current_weather').innerText = currentWeather.condition.text;
        document.getElementById('current_temp').innerHTML = currentWeather.temp_c +'<span> &#8451;</span>';
        document.getElementById('icon').innerHTML = `<img src = ${currentWeather.condition.icon} > `;
        document.getElementById('last_updt').innerText = currentWeather.last_updated;

        // Tomorrow's Weather
        document.getElementById('day1_date').innerText = day1.date;
        document.getElementById('day1_avg_temp').innerHTML = day1.day.avgtemp_c +'<span> &#8451;</span>';
        document.getElementById('day1_condition').innerText = day1.day.condition.text;
        document.getElementById('day1_icon').innerHTML = `<img src = ${day1.day.condition.icon}> `;

        // Day After Tomorrow
        document.getElementById('day2_date').innerText = day2.date;
        document.getElementById('day2_avg_temp').innerHTML = day2.day.avgtemp_c +'<span> &#8451;</span>';
        document.getElementById('day2_condition').innerText = day2.day.condition.text;
        document.getElementById('day2_icon').innerHTML = `<img src = ${day2.day.condition.icon}> `;


})
}