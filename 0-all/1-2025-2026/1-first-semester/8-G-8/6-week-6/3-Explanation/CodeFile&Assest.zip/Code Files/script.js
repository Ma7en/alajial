var image = '';

var image_names = ['architecture.jpg' , 'fox.jpg' , 'macaw.jpg' , 'night.jpg' , 'paddy.jpg' , 'sunset.jpg' , 'zebra.jpg'];

image = `<div> 
            <img src="Images/${image_names[0]}" >
         </div> 
        <div> 
            <img src="Images/${image_names[1]}" onclick=previewImages(this.src) >
        </div>

        <div> 
            <img src="Images/${image_names[2]}" onclick=previewImages(this.src)>
        </div>

        <div> 
            <img src="Images/${image_names[3]}" onclick=previewImages(this.src)>
        </div>

        <div> 
            <img src="Images/${image_names[4]}" onclick=previewImages(this.src) >
        </div>

        <div> 
            <img src="Images/${image_names[5]}" onclick=previewImages(this.src)>
        </div>

        <div> 
            <img src="Images/${image_names[6]}" onclick=previewImages(this.src)>
        </div>  `;


    document.getElementById('gallery_image').innerHTML = image;

function previewImages(image_data) {
    document.getElementById('preview_image').setAttribute('src', image_data);
}


// Same program but using Loop

// for(let i=0;i<image_names.length;i++) {
//     image += `<div class="thumbnail_image"> 
//                     <img src="Images/${image_names[i]}" onclick = getImageSrc(this.src)>
//               </div>`;
    
//     document.getElementById('gallery_image').innerHTML = image;      
// }

// function getImageSrc(e) {
//     document.getElementById('preview_image').setAttribute('src', e);
// }






